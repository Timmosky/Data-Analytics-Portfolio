```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import IsolationForest

```


```python
df = pd.read_csv(r"C:\Users\timil\Downloads\Isolation_test.csv")
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Item Description</th>
      <th>Order Fiscal Week</th>
      <th>Quantity Ordered</th>
      <th>Order Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>DA192 PWA</td>
      <td>202102</td>
      <td>1</td>
      <td>2021-01-08 06:26:00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>DA192 PWA</td>
      <td>202103</td>
      <td>1</td>
      <td>2021-01-12 16:48:00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>DA192 PWA</td>
      <td>202104</td>
      <td>1</td>
      <td>2021-01-20 12:57:00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>DA192 PWA</td>
      <td>202104</td>
      <td>1</td>
      <td>2021-01-22 19:46:00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>DA192 PWA</td>
      <td>202105</td>
      <td>1</td>
      <td>2021-01-28 06:26:00</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>452</th>
      <td>DA192 PWA</td>
      <td>202252</td>
      <td>1</td>
      <td>2022-12-28 08:45:00</td>
    </tr>
    <tr>
      <th>453</th>
      <td>DA192 PWA</td>
      <td>202252</td>
      <td>1</td>
      <td>2022-12-29 01:15:00</td>
    </tr>
    <tr>
      <th>454</th>
      <td>DA192 PWA</td>
      <td>202252</td>
      <td>1</td>
      <td>2022-12-29 03:04:00</td>
    </tr>
    <tr>
      <th>455</th>
      <td>DA192 PWA</td>
      <td>202252</td>
      <td>1</td>
      <td>2022-12-30 08:36:00</td>
    </tr>
    <tr>
      <th>456</th>
      <td>DA192 PWA</td>
      <td>202252</td>
      <td>1</td>
      <td>2022-12-30 13:00:00</td>
    </tr>
  </tbody>
</table>
<p>457 rows × 4 columns</p>
</div>




```python
df.isna().sum()
```




    Item Description     0
    Order Fiscal Week    0
    Quantity Ordered     0
    Order Date           0
    dtype: int64




```python
df.dtypes
```




    Item Description     object
    Order Fiscal Week     int64
    Quantity Ordered      int64
    Order Date           object
    dtype: object




```python
df['Order Date'] = pd.to_datetime(df['Order Date'])
```


```python
df.dtypes
```




    Item Description             object
    Order Fiscal Week             int64
    Quantity Ordered              int64
    Order Date           datetime64[ns]
    dtype: object




```python
df['Order Fiscal Week'] = pd.to_datetime(df['Order Fiscal Week'])
```


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Item Description</th>
      <th>Order Fiscal Week</th>
      <th>Quantity Ordered</th>
      <th>Order Date</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>DA192 PWA</td>
      <td>1970-01-01 00:00:00.000202102</td>
      <td>1</td>
      <td>2021-01-08 06:26:00</td>
    </tr>
    <tr>
      <th>1</th>
      <td>DA192 PWA</td>
      <td>1970-01-01 00:00:00.000202103</td>
      <td>1</td>
      <td>2021-01-12 16:48:00</td>
    </tr>
    <tr>
      <th>2</th>
      <td>DA192 PWA</td>
      <td>1970-01-01 00:00:00.000202104</td>
      <td>1</td>
      <td>2021-01-20 12:57:00</td>
    </tr>
    <tr>
      <th>3</th>
      <td>DA192 PWA</td>
      <td>1970-01-01 00:00:00.000202104</td>
      <td>1</td>
      <td>2021-01-22 19:46:00</td>
    </tr>
    <tr>
      <th>4</th>
      <td>DA192 PWA</td>
      <td>1970-01-01 00:00:00.000202105</td>
      <td>1</td>
      <td>2021-01-28 06:26:00</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>452</th>
      <td>DA192 PWA</td>
      <td>1970-01-01 00:00:00.000202252</td>
      <td>1</td>
      <td>2022-12-28 08:45:00</td>
    </tr>
    <tr>
      <th>453</th>
      <td>DA192 PWA</td>
      <td>1970-01-01 00:00:00.000202252</td>
      <td>1</td>
      <td>2022-12-29 01:15:00</td>
    </tr>
    <tr>
      <th>454</th>
      <td>DA192 PWA</td>
      <td>1970-01-01 00:00:00.000202252</td>
      <td>1</td>
      <td>2022-12-29 03:04:00</td>
    </tr>
    <tr>
      <th>455</th>
      <td>DA192 PWA</td>
      <td>1970-01-01 00:00:00.000202252</td>
      <td>1</td>
      <td>2022-12-30 08:36:00</td>
    </tr>
    <tr>
      <th>456</th>
      <td>DA192 PWA</td>
      <td>1970-01-01 00:00:00.000202252</td>
      <td>1</td>
      <td>2022-12-30 13:00:00</td>
    </tr>
  </tbody>
</table>
<p>457 rows × 4 columns</p>
</div>




```python
weekly = (
    df.groupby(["Item Description", pd.Grouper(key="Order Date", freq="W")])["Quantity Ordered"]
    .sum()
    .reset_index()
)
```


```python
weekly
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Item Description</th>
      <th>Order Date</th>
      <th>Quantity Ordered</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>DA192 PWA</td>
      <td>2021-01-10</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1</th>
      <td>DA192 PWA</td>
      <td>2021-01-17</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2</th>
      <td>DA192 PWA</td>
      <td>2021-01-24</td>
      <td>2</td>
    </tr>
    <tr>
      <th>3</th>
      <td>DA192 PWA</td>
      <td>2021-01-31</td>
      <td>2</td>
    </tr>
    <tr>
      <th>4</th>
      <td>DA192 PWA</td>
      <td>2021-02-07</td>
      <td>2</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>86</th>
      <td>DA192 PWA</td>
      <td>2022-12-04</td>
      <td>8</td>
    </tr>
    <tr>
      <th>87</th>
      <td>DA192 PWA</td>
      <td>2022-12-11</td>
      <td>11</td>
    </tr>
    <tr>
      <th>88</th>
      <td>DA192 PWA</td>
      <td>2022-12-18</td>
      <td>12</td>
    </tr>
    <tr>
      <th>89</th>
      <td>DA192 PWA</td>
      <td>2022-12-25</td>
      <td>14</td>
    </tr>
    <tr>
      <th>90</th>
      <td>DA192 PWA</td>
      <td>2023-01-01</td>
      <td>9</td>
    </tr>
  </tbody>
</table>
<p>91 rows × 3 columns</p>
</div>




```python
results = []
for item, subdf in weekly.groupby("Item Description"):
    X = subdf[["Quantity Ordered"]].values

    # Initialize Isolation Forest
    iso = IsolationForest(
        contamination=0.05,
        random_state=42
    )
    iso.fit(X)

    # Predict anomalies
    subdf["Anomaly_Score"] = iso.decision_function(X)
    subdf["Anomaly"] = iso.predict(X)
    

    results.append(subdf)

anomaly_df = pd.concat(results).reset_index(drop=True)

```


```python
item_to_plot = anomaly_df["Item Description"].unique()[0]  # change as needed
subset = anomaly_df[anomaly_df["Item Description"] == item_to_plot]

plt.figure(figsize=(12, 6))
plt.plot(subset["Order Date"], subset["Quantity Ordered"], label="Weekly Qty", marker="o")
plt.scatter(
    subset.loc[subset["Anomaly"] == -1, "Order Date"],
    subset.loc[subset["Anomaly"] == -1, "Quantity Ordered"],
    color="red",
    label="Anomaly (High Qty)",
    s=100,
)
plt.title(f"Weekly Quantity with Anomalies for {item_to_plot}")
plt.xlabel("Week")
plt.ylabel("Quantity Ordered")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
```


    
![png](output_11_0.png)
    



```python
print(anomaly_df[anomaly_df["Anomaly"] == -1].sort_values(by=["Item Description", "Order Date"]))

```

       Item Description Order Date  Quantity Ordered  Anomaly_Score  Anomaly
    63        DA192 PWA 2022-06-26                10      -0.015839       -1
    77        DA192 PWA 2022-10-02                14      -0.013600       -1
    81        DA192 PWA 2022-10-30                15      -0.085567       -1
    84        DA192 PWA 2022-11-20                18      -0.175097       -1
    89        DA192 PWA 2022-12-25                14      -0.013600       -1
    


```python

```
